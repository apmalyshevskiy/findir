#!/bin/sh
# ══════════════════════════════════════════════════════════════════
# FINDIR — daily MariaDB backup
#
# Дампит ВСЕ БД (findir_central + все findir_{slug}) одним архивом,
# хранит последние N дней (по умолчанию 14)
# ══════════════════════════════════════════════════════════════════
set -e

DATE=$(date +%Y%m%d-%H%M)
BACKUP_FILE="/backups/findir-${DATE}.sql.gz"
KEEP_DAYS=${KEEP_DAYS:-14}

echo "[$(date)] Starting backup → $BACKUP_FILE"

# Дамп всех БД findir_*  (mariadb-dump поддерживает шаблоны через --databases)
mariadb-dump \
    -h "$DB_HOST" \
    -u "$DB_USER" \
    -p"$DB_PASSWORD" \
    --all-databases \
    --single-transaction \
    --quick \
    --routines \
    --triggers \
    --events \
    --hex-blob \
    --skip-lock-tables \
  | gzip -9 > "$BACKUP_FILE"

SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
echo "[$(date)] Done. Size: $SIZE"

# Чистим старые
echo "[$(date)] Cleaning backups older than $KEEP_DAYS days..."
find /backups -name "findir-*.sql.gz" -mtime +$KEEP_DAYS -delete

echo "[$(date)] Backup complete"
