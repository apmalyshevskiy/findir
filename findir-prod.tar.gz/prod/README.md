# FINDIR — Production deployment

Полный набор файлов для деплоя FINDIR на сервер Selectel (или любой Linux).

## Структура

```
findir/                          ← корень проекта на сервере (например /opt/findir)
├── docker-compose.prod.yml      ← production compose (вместо dev)
├── .env.production              ← секреты, НЕ в гите
├── back/                        ← Laravel (из гита)
├── front-dist/                  ← собранный фронт (npm run build → копируется сюда)
├── nginx/
│   └── findir.conf
├── mariadb/
│   ├── my.cnf
│   └── init.sql
├── php/
│   ├── Dockerfile.prod
│   ├── docker-entrypoint.sh
│   └── conf/
│       ├── php.ini
│       ├── opcache.ini
│       └── www.conf
└── backup/
    └── backup.sh
```

## Что положить в гит, что нет

**В гит:**
- `docker-compose.prod.yml`
- `nginx/`, `mariadb/`, `php/`, `backup/` (все конфиги)
- `back/` (Laravel-приложение)
- `.env.production.example` (шаблон)

**В .gitignore:**
- `.env.production` (реальные секреты)
- `front-dist/` (билдится локально и копируется)
- `backups/` (если будут лежать в репо)

## Деплой первый раз

### На dev-машине (Windows)

```cmd
REM 1. Собрать фронт
cd c:\work\findir\front
npm run build

REM 2. Скопировать на сервер
scp -r dist user@findir.example.com:/opt/findir/front-dist
```

### На сервере (Ubuntu)

```bash
# 1. Поставить docker и compose plugin
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo usermod -aG docker $USER
newgrp docker

# 2. Склонировать проект
sudo mkdir -p /opt/findir
sudo chown $USER:$USER /opt/findir
git clone https://github.com/youruser/findir.git /opt/findir
cd /opt/findir

# 3. Создать .env.production из шаблона
cp .env.production.example .env.production
nano .env.production
# Изменить:
#   APP_URL → твой домен или IP
#   APP_KEY → пока пусто, сгенерируем ниже
#   DB_PASSWORD, DB_ROOT_PASSWORD → сильные пароли

# 4. Скачать фронт (или scp'нуть с dev-машины)
mkdir -p front-dist
# (фронт уже скопирован через scp на шаге выше)

# 5. Поднять стек (БЕЗ php пока — нужен APP_KEY)
docker compose -f docker-compose.prod.yml --env-file .env.production build php

# 6. Сгенерировать APP_KEY
docker compose -f docker-compose.prod.yml --env-file .env.production run --rm php php artisan key:generate --show
# Вывод вида: base64:ABC123...
# Вставить в .env.production → APP_KEY=base64:ABC123...

# 7. Полный запуск
docker compose -f docker-compose.prod.yml --env-file .env.production up -d

# 8. Прогон центральных миграций
docker compose -f docker-compose.prod.yml exec php php artisan migrate --force

# 9. Создать первого тенанта (или пользователя для регистрации)
docker compose -f docker-compose.prod.yml exec mariadb \
    mariadb -ufindir -p$DB_PASSWORD findir_central \
    -e "INSERT INTO tenants (id, name, plan, status, created_at, updated_at)
        VALUES ('demo', 'Demo', 'trial', 'active', NOW(), NOW())"

docker compose -f docker-compose.prod.yml exec php \
    php artisan tenants:migrate --tenant=demo --fresh --seed --force
```

Открываешь `http://findir.example.com` (или IP сервера) — фронт должен загрузиться.

## Обновление кода (CI/CD)

```bash
cd /opt/findir
git pull

# Если поменялся фронт — скопировать новый билд через scp с dev-машины
scp -r dist user@findir.example.com:/opt/findir/front-dist

# Если поменялся PHP/composer — пересобрать образ
docker compose -f docker-compose.prod.yml --env-file .env.production up -d --build php horizon scheduler

# Прогнать новые миграции
docker compose -f docker-compose.prod.yml exec php php artisan migrate --force
# Для тенантов (если есть тенантные миграции):
docker compose -f docker-compose.prod.yml exec php php artisan tenants:migrate --force
```

## Бэкапы

Запускаются автоматически каждый день в 03:00 UTC через cron внутри `findir_backup`.

Скачать последний бэкап на dev-машину:
```bash
# На сервере посмотреть список
docker compose -f docker-compose.prod.yml exec backup ls -lh /backups

# Скопировать в текущую папку
docker cp findir_backup:/backups/findir-20260520-0300.sql.gz .

# И тянуть с dev-машины
scp user@findir.example.com:/opt/findir/findir-*.sql.gz ./backups-local/
```

Восстановление из бэкапа:
```bash
gunzip -c findir-20260520-0300.sql.gz | \
    docker compose -f docker-compose.prod.yml exec -T mariadb \
        mariadb -uroot -p$DB_ROOT_PASSWORD
```

**Важно:** для S3-хранения бэкапов (Selectel Object Storage) добавь cron на хосте:
```
0 4 * * * aws s3 sync /var/lib/docker/volumes/findir_backups/_data s3://findir-backups/ --endpoint-url https://s3.selcloud.ru
```

## Что отличается от dev

| Аспект | Dev | Prod |
|---|---|---|
| MariaDB порт наружу | 3307 | НЕТ (`expose:` только внутри сети) |
| phpMyAdmin | есть | НЕТ |
| Redis Commander | есть | НЕТ |
| Mailpit | есть | НЕТ (реальный SMTP в env) |
| Vite dev-сервер | есть (node:20) | НЕТ (статика nginx-ом) |
| `APP_ENV` | local | production |
| `APP_DEBUG` | true | false |
| OPcache | dev-настройки | агрессивный кеш (validate_timestamps=0) |
| Composer | dev-зависимости | `--no-dev`, оптимизированный autoload |
| Laravel кеши | очищаются | `config/route/view/event:cache` |
| Бэкапы | НЕТ | daily, ротация 14 дней |
| Логи PHP | stderr | error_log + slowlog |

## Что добавить позже

- **SSL.** Когда появится домен — самый простой путь:
  - Поставить Caddy перед nginx (Caddy ↔ 443, nginx ↔ 80 внутри сети)
  - Или Cloudflare proxy (SSL на их стороне, до сервера HTTP)
- **Мониторинг.** Минимум — `docker stats` через uptime-kuma или netdata
- **Алерты на бэкапы.** Если бэкап-скрипт упадёт — узнать об этом
- **S3 для бэкапов.** Локальные тома уязвимы, надо синкать в Object Storage Selectel

## Если что-то не работает

- `docker compose -f docker-compose.prod.yml logs -f php` — смотрит логи php-fpm
- `docker compose -f docker-compose.prod.yml logs -f nginx` — nginx
- `docker compose -f docker-compose.prod.yml exec php php artisan tinker` — отладка Laravel
- `docker compose -f docker-compose.prod.yml exec mariadb mariadb -uroot -p$DB_ROOT_PASSWORD` — прямой доступ к БД
