#!/bin/sh
# ══════════════════════════════════════════════════════════════════
# FINDIR — PHP entrypoint (production)
#
# При каждом старте контейнера:
#  1. Чистим старые кеши
#  2. Кешируем config / routes / views / events
#  3. Запускаем переданную команду (php-fpm или artisan)
# ══════════════════════════════════════════════════════════════════
set -e

# Только если это основной php-fpm процесс — прогреваем кеши.
# Для horizon/scheduler пропускаем (они дёргают то же приложение).
if [ "$1" = "php-fpm" ]; then
    echo "→ Clearing old caches..."
    php artisan config:clear  || true
    php artisan route:clear   || true
    php artisan view:clear    || true
    php artisan event:clear   || true

    echo "→ Caching for production..."
    php artisan config:cache
    php artisan route:cache
    php artisan view:cache
    php artisan event:cache

    echo "→ Ensuring storage symlink..."
    php artisan storage:link || true

    echo "→ Ready"
fi

exec "$@"
